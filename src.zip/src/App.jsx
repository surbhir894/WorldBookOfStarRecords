import './App.css'
import Awards from './components/awards/Awards';
import Carousel from './components/carousel/Carousel';
import ContactForm from './components/contact/ContactForm';
import FAQ from './components/faq/FAQ';
import Footer from './components/footer/Footer';
import Navbar from "./components/Navbar/Navbar";
import Register from './components/registeration/Register';

function App() {
  return (
    <>
      <Navbar />
      <Carousel/>
      <Awards/>
      <FAQ/>
      <ContactForm/>
      <Register/>
      <Footer/>
     
    </>
  );
}

export default App;
