import { FaUserCircle } from "react-icons/fa";
import logo from "../../assets/images/logo.png";
import { useState } from "react";

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-zinc-900 shadow-md fixed top-0 w-full z-10">
      <div className="container mx-auto px-4 md:px-8 h-auto">
        {/* Logo and Title */}
        <div className="flex flex-col md:flex-row items-center justify-center md:justify-between py-4 md:py-0">
          {/* Logo and Title Container */}
          <div className="flex items-center justify-center space-x-4 mb-4 md:mb-0 w-full md:w-auto">
            {/* Logo Image */}
            <img
              src={logo}
              alt="Logo"
              className="h-24 w-auto object-contain md:h-32"
            />
            <h1 className="text-white text-3xl md:text-4xl font-extrabold tracking-wider">
              World Book of <span className="text-red-500">Star Records</span>
            </h1>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-white focus:outline-none"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <svg
              className="w-8 h-8"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
              />
            </svg>
          </button>
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex justify-center space-x-8 py-2">
          {["HOME", "AWARDS", "RECORDS", "MEDIA", "GALLERY", "EVENTS", "TESTIMONIALS", "ABOUT"].map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="text-white text-xl hover:font-bold hover:text-red-500 transition-transform transform hover:scale-110"
            >
              {link}
            </a>
          ))}
          <a
            href="#register"
            className="flex items-center text-white text-xl hover:font-bold hover:text-red-500 transition-transform transform hover:scale-110"
          >
            <FaUserCircle className="mr-2" />
            REGISTER
          </a>
        </div>

        {/* Mobile Links */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-blue-900 shadow-md">
            {["HOME", "AWARDS", "RECORDS", "MEDIA", "GALLERY", "EVENTS", "TESTIMONIALS", "ABOUT"].map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase()}`}
                className="block text-white text-lg hover:font-bold hover:text-red-500 px-4 py-2 transition-transform transform hover:scale-110"
              >
                {link}
              </a>
            ))}
            <a
              href="#register"
              className="block flex items-center text-white text-lg hover:font-bold hover:text-red-500 px-4 py-2 transition-transform transform hover:scale-110"
            >
              <FaUserCircle className="mr-2" />
              REGISTER
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
